package com.foodapp.FoodApp.cart.service;

import com.foodapp.FoodApp.auth_users.entity.User;
import com.foodapp.FoodApp.auth_users.service.IUserService;
import com.foodapp.FoodApp.cart.dtos.CartDTO;
import com.foodapp.FoodApp.cart.entity.Cart;
import com.foodapp.FoodApp.cart.entity.CartItem;
import com.foodapp.FoodApp.cart.repository.CartItemRepository;
import com.foodapp.FoodApp.cart.repository.CartRepository;
import com.foodapp.FoodApp.exceptions.NotFoundException;
import com.foodapp.FoodApp.menu.entity.Menu;
import com.foodapp.FoodApp.menu.repository.MenuRepository;
import com.foodapp.FoodApp.response.Response;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class CartServiceImpl implements ICartService {

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final MenuRepository menuRepository;
    private final IUserService userService;
    private final ModelMapper modelMapper;


    @Override
    public Response<?> addItemToCart(CartDTO cartDTO) {
        log.info("INSIDE addItemToCart()");

        Long menuId = cartDTO.getMenuId();
        int quantity = cartDTO.getQuantity();

        User user = userService.getCurrentLoggedInUser();

        Menu menu = menuRepository.findById(menuId)
                .orElseThrow(()-> new NotFoundException("Menu item not found"));

        Cart cart = cartRepository.findByUser_Id(user.getId())
                .orElseGet(()-> {
                    Cart newCart = new Cart();
                    newCart.setUser(user);
                    newCart.setCartItems(new ArrayList<>());
                    return cartRepository.save(newCart);
                });

        //Check if the item is already in the  cart
        Optional<CartItem> optionalCartItem = cart.getCartItems().stream()
                .filter(cartItem -> cartItem.getMenu().getId().equals(menuId))
                .findFirst();

        //if present, increment item
        if(optionalCartItem.isPresent()){

            CartItem cartItem = optionalCartItem.get();
            cartItem.setQuantity(cartItem.getQuantity() + quantity);
            cartItem.setSubtotal(cartItem.getPricePerUnit().multiply(BigDecimal.valueOf(cartItem.getQuantity())));
            cartItemRepository.save(cartItem);
        }

        if(optionalCartItem.isEmpty()){
            CartItem newCartItem = CartItem.builder()
                    .cart(cart)
                    .menu(menu)
                    .quantity(quantity)
                    .pricePerUnit(menu.getPrice())
                    .subtotal(menu.getPrice().multiply(BigDecimal.valueOf(quantity)))
                    .build();

            cart.getCartItems().add(newCartItem);
            cartItemRepository.save(newCartItem);
        }

        //cartRepository.save(cart); DO NOT need to do this because cartItem in cart has cascade set

        return Response.builder()
                .statusCode(HttpStatus.OK.value())
                .message("Item added to cart successfully")
                .build();
    }

    @Override
    public Response<?> incrementItem(Long menuId) {
        return null;
    }

    @Override
    public Response<?> decrementItem(Long menuId) {
        return null;
    }

    @Override
    public Response<?> removeItem(Long cartItemId) {
        return null;
    }

    @Override
    public Response<CartDTO> getShoppingCart() {
        return null;
    }

    @Override
    public Response<?> clearShoppingCart() {
        return null;
    }
}
